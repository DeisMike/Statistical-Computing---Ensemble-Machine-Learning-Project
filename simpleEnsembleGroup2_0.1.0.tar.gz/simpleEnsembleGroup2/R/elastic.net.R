#' Fit a generalized linear model with elastic net regularization
#'
#' This function fits a generalized linear model via penalized maximum
#' likelihood. The regularization path is computed for the elastic net penalty
#' at a grid of values for the regularization parameter lambda.
#' Any missing values in either the set of predictors or the response variable
#' will be removed. Utilizes the glmnet package to perform either linear or
#' logistic  regression models with cross validation.

#' @param X Matrix of candidate predictors/independent variables.
#' @param y Response variable. For binary classification, it should be a
#' factor variable with two levels. For linear regression, it should be a
#' numeric vector.
#' @param family Type of model. Options are \code{"gaussian"} (Default) for linear
#' regression and \code{"binomial"} for logistic regression.
#' @param alpha Mixing parameter of the elastic net penalty. It controls the
#' balance between L1 and L2 regularization. Default is 0.5.
#' @param nlambda Number of penalty parameter values to use in the
#' regularization path. Default is 100.
#'
#' @return Elastic net model object.
#' @export
#' @import glmnet
#' @examples
#' # Sample Data
#' set.seed(123)
#' # For binary outcome
#' binary_data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y_binary = factor(sample(0:1, 100, replace = TRUE))
#' )
#'
#' # For continuous outcome
#' continuous_data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y_continuous = rnorm(100)
#' )
#'
#'
#' # Example usage for binary outcome
#' binary_fit <- elastic.net(
#'   X = binary_data[, c("x1", "x2")],
#'   y = binary_data$y_binary,
#'   family = 'binomial',
#'   alpha = 0.5,
#'   nlambda = 100
#' )
#'
#' # Example usage for continuous outcome
#' continuous_fit <- elastic.net(
#'   X = continuous_data[, c("x1", "x2")],
#'   y = continuous_data$y_continuous,
#'   family = 'gaussian',
#'   alpha = 0.5,
#'   nlambda = 100
#' )
#'


elastic.net <- function(X, y, family = 'gaussian', alpha = 0.5, nlambda = 100){
  X <- na.omit(X)
  y <- na.omit(y)
  X <- as.matrix(X)
  y <- as.matrix(y)

  if (family == 'binomial'){
    #Binary outcome case
    fit <- glmnet::glmnet(X, y, family = 'binomial',
                          alpha = alpha, nlambda = nlambda)
    cv.fit <- glmnet::cv.glmnet(X, y, family= "binomial", alpha = alpha)
  }
  else if (family == 'gaussian'){
    #Continuous outcome case
    fit <- glmnet::glmnet(X, y, family = 'gaussian',
                          alpha = alpha, nlambda = nlambda)
    cv.fit <- glmnet::cv.glmnet(X, y, alpha = alpha)
  }
  else {
    stop("The family argument must either be binomial or gaussian")

  }
  best.lambda <- cv.fit$lambda.min
  predictions <- predict(fit, newx = X, s = best.lambda)

  #Returning both the fitted model and the lambda value
  return(list(fit = fit, lambda = best.lambda))
}


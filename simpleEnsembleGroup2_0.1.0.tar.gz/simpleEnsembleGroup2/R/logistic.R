#' Fit a logistic regression model
#'
#' This function performs logistic regression using the glm function found
#' in the base package of R to perform binary classification. It takes input
#' data X and corresponding binary response variable y. Any missing values in
#' either the set of predictors or the response variable will be removed before
#' fitting the model.

#' @param X Matrix of candidate predictors/independent variables.
#' @param y Response variable that should be a binary numeric vector, only containing two unique values.
#' @param k Option to pre-screen for the top k most informative predictors. Default is no pre-screening.
#'
#' @return Logistic regression model object
#' @export
#' @examples
#' #Load sample data
#' set.seed(123)
#' #FIX
#' binary_resp_data <- binary_resp_data
#'
#' #Fit logistic regression model using all predictors
#' logistic_model <- logistic(X = binary_resp_data[, -21],
#'                            y = binary_resp_data$y_binary)
#' #Check AIC for the model with all predictors
#' AIC(logistic_model)
#'
#' #Perform logistic regression model with pre-screening
#' prescreen_model <- logistic(X = binary_resp_data[, -21],
#'                             y = binary_resp_data$y_binary, k = 4)
#' #Check AIC after pre-screen to see if it is lower (better model)
#' AIC(prescreen_model)
#'
#' @seealso \code{\link{glm}}, \code{\link[prescreen]{prescreen}}
#'

logistic <- function(X, y, k = NULL){

  X <- na.omit(X)
  y <- na.omit(y)

  #Convert into data frame if not already
  X <- as.data.frame(X)

  #Check that y only takes two unique values
  if(length(unique(y))!=2) {
    stop("y is not a binary response variable")
  }

  #If there is a specified value for k, do pre-screening
  if(!is.null(k)) {
    predictors <- prescreen(X, y, k, type = "binomial")
    X <- X[, predictors]
  }

  #Combine predictors and response into a single data frame
  data_matrix <- cbind(X, y)

  #Make the y response binary
  data_matrix$y <- y

  #Get rid of missing values
  data_matrix <- na.omit(data_matrix)

  #Fit the model with the data input by the user
  model <- glmnet(X, y, family = "binomial")

  return(model)
}

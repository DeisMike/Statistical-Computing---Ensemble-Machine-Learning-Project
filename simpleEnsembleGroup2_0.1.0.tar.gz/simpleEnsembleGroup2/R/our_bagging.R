#' Bagging Function: Sample With Replacement R times.
#'
#' This function implements bagging (bootstrap aggregating)

#' @param Xtrain A matrix of the predictor variables as training data
#' @param Xtest A matrix of the predictor variables as testing data
#' @param ytrain A vector of the response variable as training data
#' @param model The regression model that the user wants to perform bagging on ("linear", "logistic", "ridge", "lasso", "elastic")
#' @param R An integer R, how many times the user wants to perform sampling with replacement
#'
#' @return A list of 3 outputs: bagged_preds, final_preds, and variable_importance
#' bagged_preds: A matrix of the bagged predictions, that is a matrix with R columns where column j represents the set of predictions made by model j in the bagging process.
#' final_preds: A vector of final predictions, that is the decided final predictions based on aggregating the bagged predictions
#' variable_importance: The variable importance score
#' @export
#' @examples
#'
#' *Note, if there are some categorical predictors, the training data should be input as a dataframe where the
#' categorical variable column is a factor variable. The bagging function will implement model.matrix on Xtrain training data
#' However, if there are some categorical predictors in the testing data, Xtest should be provided having already performed model.matrix
#' This is show in the first example below
#'
#' #TESTING BAGGING ON LINEAR REGRESSION
#'
#' #Creating Data Set for Testing
#' X <- data.frame(data=cbind(ChickWeight$Time, ChickWeight$Diet))
#' X[,2] <- as.factor(X[,2])
#' trainID <- sample(578, 0.75 * 578)
#'
#' #NOTE*** Xtrain should be factorized since there are categorical predictors, but do NOT make model.matrix
#' #on the TRAINING data. DO model.matrix on the TESTING data.
#' Xtrain <- X[trainID,]
#' y <- ChickWeight$weight
#' ytrain <- y[trainID]
#'
#' Xtest <- X[-trainID,]
#' Xtest <- model.matrix(~., data=Xtest)
#' Xtest <- as.data.frame(Xtest)
#' ytest <- y[-trainID]
#'
#' results <- our_bagging(Xtrain=Xtrain, Xtest=Xtest, ytrain=y, model="linear", R=40)
#' total <- cbind(results$bagged_preds, results$final_preds)
#' total
#'
#' results$variable_importance
#'
#'
#' #TESTING BAGGING ON LOGISTIC REGRESSION
#' data("PimaIndiansDiabetes2", package = "mlbench")
#' data <- PimaIndiansDiabetes2
#' data <- na.omit(data)
#'
#' # Pre-create training and testing data
#' trainID <- sample(392, 0.75 * 392)
#'
#' Xtrain2 <- data[trainID,-9]
#' ytrain2 <- data[trainID,9]

#' Xtest2 <- data[-trainID, -9]
#' Xtest2 <- as.matrix(Xtest2)
#' ytest2 <- data[-trainID, 9]
#'
#' results2 <- our_bagging(Xtrain2, Xtest2, ytrain2, model="logistic", R=10)
#' total2 <- cbind(results2$bagged_preds, results2$final_preds)
#' total2
#' results2$variable_importance
#'
#' #CREATING SAMPLE DATA FOR TESTING RIDGE, LASSO, AND ELASTIC NET
#'
#' # Sample Data
#' set.seed(123)
#  For binary outcome
#' binary_data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y_binary = factor(sample(0:1, 100, replace = TRUE))
#' )
#'
#' #Split into training and testing
#' Xtrain3 <- binary_data[1:75, c("x1", "x2")]
#' y = binary_data$y_binary
#' ytrain3 <- y[1:75]
#'
#' Xtest3 <- binary_data[76:100, c("x1", "x2")]
#' ytest3 <- y[76:100]
#'
#' # For continuous outcome
#' continuous_data <- data.frame(
#'  x1 = rnorm(100),
#'  x2 = rnorm(100),
#'  y_continuous = rnorm(100)
#' )
#'
#' #Split into training and testing
#' Xtrain4 <- continuous_data[1:75, c("x1", "x2")]
#' yc = continuous_data$y_continuous
#' ytrain4 <- yc[1:75]
#' Xtest4 <- continuous_data[76:100, c("x1", "x2")]
#' ytest4<- yc[76:100]
#'
#' #TESTING BAGGING ON RIDGE
#'
#' #Binary Example
#' ridge_results <- our_bagging(Xtrain=Xtrain3, Xtest=Xtest3, ytrain=ytrain3, model="ridge", R=15)
#' total5 <- cbind(ridge_results$bagged_preds, ridge_results$final_preds)
#' total5
#' ridge_results$variable_importance
#'
#' #Continuous Example
#' ridge_results_cont <- our_bagging(Xtrain=Xtrain4, Xtest=Xtest4, ytrain=ytrain4, model="ridge", R=20)
#' total5_cont <- cbind(ridge_results_cont$bagged_preds, ridge_results_cont$final_preds)
#' total5_cont
#' ridge_results_cont$variable_importance
#'
#' #TESTING BAGGING ON LASSO
#'
#' #Binary Example
#' lasso_results2 <- our_bagging(Xtrain=Xtrain2, Xtest=Xtest2, ytrain=ytrain2, model="lasso", R=100)
#' total4.2 <- cbind(lasso_results2$bagged_preds, lasso_results2$final_preds)
#' total4.2
#' lasso_results2$variable_importance
#'
#' #Continuous Example
#' lasso_results_cont <- our_bagging(Xtrain=Xtrain4, Xtest=Xtest4, ytrain=ytrain4, model="lasso", R=50)
#' total4_cont <- cbind(lasso_results_cont$bagged_preds, lasso_results_cont$final_preds)
#' total4_cont
#' lasso_results_cont$variable_importance
#'
#' #TESTING BAGGING ON ELASTIC NET
#'
#' #Binary Example
#' elastic_results2 <- our_bagging(Xtrain=Xtrain2, Xtest=Xtest2, ytrain=ytrain2, model="elastic", R=100)
#' total3.2 <- cbind(elastic_results2$bagged_preds, elastic_results2$final_preds)
#' total3.2
#' elastic_results2$variable_importance
#'
#' #Continuous Example
#' Note: here we use a case with categorical predictors, the testing data Xtest has already performed model,matrix which
#' adds a column for intercept, this column should be excluded when feeding into the our_bagging function
#'
#' elastic_results_cont <- our_bagging(Xtrain=Xtrain, Xtest=Xtest[,-1], ytrain=ytrain, model="elastic", R=17)
#' total3_cont <- cbind(elastic_results_cont$bagged_preds, elastic_results_cont$final_preds)
#' total3_cont
#'
#' elastic_results_cont$variable_importance

our_bagging <- function(Xtrain, Xtest, ytrain, model, R) {

  family <- "" #Initialize family?
  int_yn <- "TRUE" #Initialize intercept to be true
  num_train <- as.numeric(dim(Xtrain)[1])
  num_test <- as.numeric(dim(Xtest)[1])

  #Check if the input response vector is binary or continuous
  uniquey <- unique(ytrain)
  num_uniquey <- length(uniquey)
  if(num_uniquey == 2){
    resp_type <- "binary"
  }
  else{
    resp_type <- "continuous"
  }

  if(resp_type=="binary"){
    u <- unique(ytrain)
    ytrain <- ifelse(ytrain==u[1], 0, 1)
    ytrain <- as.numeric(ytrain)
  }

  #Get appropriate user input for regression model we are using for bagging
  if(model == "linear"){
    int_yn = readline(prompt = "Would you like to fit the bagged linear model with an intercept? Enter TRUE or FALSE ")
    int_yn <- as.character(int_yn)
  }

  else if (model == "elastic" | model == "ridge" | model == "lasso"){

    if(resp_type=="binary"){
      family <- "binomial"
    }
    else if(resp_type=="continuous"){
      family <- "gaussian"
    }

    nlambda = readline(prompt = "What number of penalty parameter values do you want to use in the regularization path? Default is 100 ")
    nlambda <- as.character(nlambda)

  }

  if(model == "elastic"){
    alpha = readline(prompt = "What alpha value do you want to use? Alpha is the mixing parameter of the elastic net penalty. \n It controls the balance between L1 and L2 regularization. Default is 0.5 ")
    alpha <- as.numeric(alpha)
  }

  #Create model.matrix dummy variables for Xtrain
  Xtrain <- model.matrix(~., data = Xtrain) #all predictors with intercept column

  #Create an array that will store the predictions of all of the R bagged models
  bagged_preds <- matrix(NA, nrow=num_test, ncol=R)

  #“naive” variable importance score which counts the number of times each variable is selected in the bagging process
  #This will be for lasso and elastic net regression methods which shrink some coefficients to zero
  variable_importance <- rep(0, ncol(Xtrain))

  #This will be to keep track of linear, logistic, and ridge regression coefficients
  #Create an empty matrix with a row for every model and a column for intercept + every predictor
  variable_coeffs <- matrix(NA, nrow=R, ncol= ncol(Xtrain))
  colnames(variable_coeffs) <- colnames(Xtrain)
  if(int_yn=="FALSE"){ #if there is no intercept for linear model, we reduce the dimension
    variable_coeffs <- matrix(NA, nrow=R, ncol= ncol(Xtrain)-1)
    colnames(variable_coeffs) <- colnames(Xtrain[,-1])
  }
  #colnames(variable_coeffs) <- colnames(Xtrain)

  set.seed(123)

  #Sample with replacement from the original sample training data
  for (i in 1:R) {

    #Randomize the seed every time before generating the sample with replacement
    set.seed(i)
    bootstrap_id <- sample(1:num_train, num_train, replace = TRUE)

    X_b <- as.data.frame(Xtrain[bootstrap_id, ])
    X_b <- X_b[,-1] #Delete the intercept column created by model.matrix because lm and glm will handle fitting intercept

    y_b <- ytrain[bootstrap_id]

    if (model == "linear") {

      currmodel <- linear(X_b,y_b, intercept=int_yn)

      predictions <- predict(currmodel, Xtest)

      bagged_preds[,i] <- predictions

      #Append current model's coefficients as a row in the variable_coeffs matrix
      estCoef = stats::coef(currmodel)
      variable_coeffs[i,] <- estCoef

    }

    else if (model == "logistic") {

      currmodel <- logistic(X_b, y_b)
      predictions <- predict(currmodel, newx = as.matrix(Xtest), type = "class")

      numcols <- dim(predictions)[2]
      predcol <- floor(.5*numcols)
      predictions <- as.numeric(predictions[,predcol])

      bagged_preds[,i] <- predictions

      #Append current model's coefficients as a row in the variable_coeffs matrix
      estCoef = stats::coef(currmodel)[,predcol]
      variable_coeffs[i,] <- estCoef

    }

    else if (model == "ridge") {

      currmodel <- ridge(X_b, y_b, family = family, nlambda = nlambda)

      if(resp_type=="binary"){

        predictions <- predict(currmodel, newx = as.matrix(Xtest), type="class")

      }

      else{ #else if resp_type is continuous
        predictions <- predict(currmodel,newx = as.matrix(Xtest), type="response")
      }

      #Extract the specific column of predictions
      numcols <- dim(predictions)[2]
      predcol <- floor(.5*numcols)
      predictions <- as.numeric(predictions[,predcol])

      bagged_preds[,i] <- predictions

      #Get coefficients for our specific model
      estCoef = stats::coef(currmodel)[,predcol]
      variable_coeffs[i,] <- estCoef

    }

    else if (model == "lasso") {

      currmodel <- Lasso(X_b,y_b, family = family, nlambda = nlambda )

      if(resp_type == "binary"){

        predictions <- predict(currmodel, newx = as.matrix(Xtest), type="class")

      }

      else{#else if resp_type is continuous
        predictions <- predict(currmodel,newx = as.matrix(Xtest), type="response")
      }


      #Extract the specific column of predictions
      numcols <- dim(predictions)[2]
      predcol <- floor(.5*numcols)
      predictions <- as.numeric(predictions[,predcol])

      bagged_preds[,i] <- predictions

      #Get coefficients for our specific model
      estCoef = stats::coef(currmodel)
      modelcoefs <- estCoef[,predcol]
    }

    else if (model == "elastic") {

      currmodel <- elastic.net(X_b, y_b, family = family, alpha = alpha, nlambda = nlambda)

      if(resp_type=="binary"){
        predictions <- predict(currmodel, newx = as.matrix(Xtest), type="class")
      }

      else{#else if resp_type is continuous
        predictions <- predict(currmodel,newx = as.matrix(Xtest), type="response")
      }

      numcols <- dim(predictions)[2]
      predcol <- floor(.5*numcols)
      predictions <- as.numeric(predictions[,predcol])

      bagged_preds[,i] <- predictions

      #Get coefficients for our specific model
      estCoef = stats::coef(currmodel)
      modelcoefs <- estCoef[,predcol]

    }

    # Update variable importance for each bagged model created; increase counter if variable included in currmodel
    if (model == "lasso" | model == "elastic") {
      variable_importance <- variable_importance + (modelcoefs != 0)
    }

  }

  #After all linear&logistic models have been created with coefficients added to variable_importance
  #We average the coefficient value over all models by taking the column mean
  if(model == "linear" | model == "logistic" | model == "ridge"){
    variable_importance <- colMeans(variable_coeffs)
  }

  #If the response variable is continuous, we will average the test prediction values
  final_preds <- apply(bagged_preds, 1, mean)

  #If the response is binary, we will use majority voting to aggregate the bagged models
  if(resp_type == "binary"){

    final_preds <- ifelse(final_preds >= 0.5, 1, 0)
  }

  #final_predictions will be a nx1 vector/matrix which has the aggregate predictions from the R bagged models
  return(list(bagged_preds=bagged_preds, final_preds=final_preds, variable_importance=variable_importance) )
}

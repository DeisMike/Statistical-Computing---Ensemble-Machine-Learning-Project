#' Sample data with a lot of predictors and not a lot of observations (p >> n)
#'
#' This data frame contains sample data to use to test the functions.
#' This data covers the case when there are way more predictors than observations.
#' The predictors consist of different genes and the outcome is a specific group.
#'
#' @format A data frame with 72 observations and 3571 predictors and 1 binary outcome variable:
#' \describe{
#'  \item{Group}{Factor: Binary response variable}
#'   \item{Group}{Factor: Binary response variable. "ALL" = 1, "AML" = 0}
#'   \item{x1}{Numeric: Gene1}
#'   \item{x2}{Numeric: Gene2}
#'   ...
#'   \item{x3571}{Numeric: Gene 3571}
#' }
#'
#' @examples
#' data(gene.data)

#Read in the data
data <- read.delim('https://www.ams.sunysb.edu/~pfkuan/Teaching/AMS597/Data/leukemiaDataSet.txt', header=T, sep='\t')

#Data cleaning
#Make the response into binary factor
data$Group <- as.factor(data$Group)

gene.data <- data

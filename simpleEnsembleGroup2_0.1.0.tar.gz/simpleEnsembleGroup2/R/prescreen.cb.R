#' Pre-screen for the K Most Informative Predictors (continuous X & binary y, large data set case)
#'
#' This function performs a pre-screening of predictors when the predictors are continuous and the response variable is binary.
#' It uses the Mann-Whitney U test `wilcox.test` to compare the distributions of each predictor variable between the two levels of the binary response.
#' The function returns the names of the top k predictors with the smallest p-values, indicating more significant differences in the distributions.
#'
#' @param X Matrix of predictor variables.
#' @param y Binary response variable.
#' @param k Number of top predictors to select.
#'
#' @return A character vector containing the names of the top k predictors.
#' @export
#'
#'
#' @examples
#'
#' str(gene.data)
#' prescreen.cb(gene.data[,-1], gene.data$Group, 20)
#'
#'@seealso \code{\link{prescreen}}

prescreen.cb <- function(X, y, k) {
  #Method for cont. predictors and binary response
  #Two sample wilcox.test = Mann Whitney test
  #Mann Whitney test compares the distribution of the predictor
  #and the distribution of the response variable and see if they differ
  #significantly.
  p_values <- sapply(X, function(x) wilcox.test(x ~ y)$p.value)

  #Grab the p-value from each predictor

  #Lower the p-value, the more different the distributions are
  top_predictors <- names(sort(p_values, decreasing = FALSE))[1:k]
  return(top_predictors)
}

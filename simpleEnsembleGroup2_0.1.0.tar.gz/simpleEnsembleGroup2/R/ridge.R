#' Fit a generalized linear model with Ridge regression
#'
#' This function performs Ridge regression on a response variable. It assumes
#' the response variable is either binary or continuous. Utilizes the glmnet
#' package to perform either linear or logistic regression. Any missing values
#' in either the set of predictors or the response variable will be removed
#' from the regression as part of data cleaning.
#'
#' @param X A matrix of the predictor/covariate variables
#' @param y Response variable y
#' @param family Type of model. Options are \code{"gaussian"} for linear
#' regression and \code{"binomial"} for logistic regression.
#' @param nlambda Number of penalty parameter values to use in the
#' regularization path. Default is 100.
#' @return A Ridge model object.
#' @export
#' @import glmnet
#' @examples
#' #Sample Data
#' set.seed(123)
#' # For binary outcome
#' binary_data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y_binary = factor(sample(0:1, 100, replace = TRUE))
#' )
#' bin_x_data = as.matrix(binary_data[1:2])
#'
#' # For continuous outcome
#' continuous_data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y_continuous = rnorm(100)
#' )
#' cts_x_data = as.matrix(continuous_data[1:2])
#'
#' #Example usage for binary outcome
#' bin_model = ridge(
#' bin_x_data,
#' binary_data$y_binary,
#' family = "binomial",
#' nlambda = 100)
#'
#' #Example usage for continuous outcome
#' cts_model = ridge(
#' cts_x_data,
#' continuous_data$y_continuous,
#' family = "gaussian",
#' nlambda = 100)
#'
#' # Summary of the fitted models
#' summary(bin_model)
#' summary(cts_model)
#'
#' #EXAMPLES:
#' data(mtcars)
#' ridge(X = data.matrix(mtcars[, c('mpg', 'wt', 'drat', 'qsec')]), y = mtcars$hp, family = "gaussian", nlambda = 100)
#'
#' ridge(X = data.matrix(mtcars[, c('mpg', 'wt', 'drat', 'qsec')]), y = mtcars$hp, family = "gaussian", nlambda = 100, k= 3)
#' @seealso \code{\link{glmnet}}, \code{\link[prescreen]{prescreen}}
#'
ridge <- function(X = NULL, y = NULL, family = c("gaussian","binomial"), nlambda = 100, k = NULL) {
  # Use match.arg to match the argument to the allowed options
  family = match.arg(family)
  # Remove missing values from the predictors and response variable
  X = na.omit(X)
  y = na.omit(y)
  X = as.matrix(X)
  if(is.null(X) == T) {
    stop("first argument, x, must be provided, formatted as a matrix")
  }
  if(is.null(y) == T) {
    stop("second argument, y, must be provided, formatted as a vector")
  }
  if(is.matrix(X) == F) {
    stop("x must be a matrix")
  }
  if(length(unique(y)) == 1) {
    stop("y must have more than one unique value")
  }
  if(is.character(y) == T & length(unique(y)) > 2) {
    stop("y must be binary (2 unique values) if it is a character vector")
  }
  #If there is a specified value for k, do pre-screening
  if(!is.null(k)) {
    predictors <- prescreen(X, y, k, type = family)
    X <- X[, predictors]
  }

  if(family == "binomial") {
    # Binary case - classification
    if(length(unique(y)) != 2){
      stop("y must have 2 unique values when family is binomial")
    }
    model = glmnet::glmnet(X, y, family = "binomial", alpha = 0, nlambda = nlambda)
  }
  else if(family == "gaussian") {
    # Continuous case - regression
    if(length(unique(y)) == 2){
      stop("y must have more than 2 unique values when family is gaussian")
    }
    if(is.vector(y) == F) {
      stop("y must be a vector of the response variable")
    }
    model = glmnet::glmnet(X, y, family = "gaussian", alpha = 0, nlambda = nlambda)
  }
  return(model)
}

#' Pre-screen for the K Most Informative Predictors Using Forward Selection
#'
#' This function filters out the k most informative predictors in a data set through
#' the use of forward selection method. The number k is chosen by the user. This function
#' can deal with a data set including binary and continuous response variables and
#' continuous and binary predictors. Currently, the function does not work well
#' when there are many predictors. Please refer to the prescreen.scale function
#' in this package to prescreen when there are many predictors.
#'
#' @param X Matrix of candidate predictors/independent variables.
#' @param y Response variable. For binary classification, it should be a
#' factor variable with two levels. For linear regression, it should be a
#' numeric vector.
#' @param k The number of predictors to be included in the model.
#' @param type Type of model. Options are \code{"gaussian"} (Default) for continuous response
#' and \code{"binary"} for binary response.
#'
#' @return A vector of k selected predictors
#'
#' @export
#' @examples
#' #Binary response variable case
#' #Create sample data
#' set.seed(123)
#' n <- 100
#' x1 <- rnorm(n)
#' x2 <- rnorm(n)
#' x3 <- rnorm(n)
#' x4 <- rnorm(n)
#' x5 <- rnorm(n)
#' x6 <- rnorm(n)
#' x7 <- rnorm(n)
#' x8 <- rnorm(n)
#' x9 <- rnorm(n)
#' x10 <- rnorm(n)
#' y <- rbinom(n, 1, 0.5)
#' #Create data frame
#' binary_resp_data <- data.frame(x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, y)
#' #Perform forward selection for logistic regression
#' selected_predictors <- prescreen(binary_resp_data[, -11], binary_resp_data$y, 2, type = "logistic")
#' # Output selected predictors
#' selected_predictors
#'
#'
#' #Continuous response variable case (linear regression)
#' #Create sample data
#' set.seed(123)
#' n <- 100
#' x1 <- rnorm(n)
#' x2 <- rnorm(n)
#' x3 <- rnorm(n)
#' x4 <- rnorm(n)
#' x5 <- rnorm(n)
#' x6 <- rnorm(n)
#' x7 <- rnorm(n)
#' x8 <- rnorm(n)
#' x9 <- rnorm(n)
#' x10 <- rnorm(n)
#' y <- rnorm(n, mean = 100, sd = 20)
#' #Create data frame
#' cont_resp_data <- data.frame(x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, y)
#' #Perform forward selection for linear regression
#' selected_predictors <- prescreen(cont_resp_data[, -11], cont_resp_data$y, 2, type = "linear")
#' # Output selected predictors
#' selected_predictors
#'
#' @seealso \code{\link{prescreen}}
#'
#' @export

prescreen.fs <- function(X, y, k, type = "gaussian") {
  #Function to select predictors using AIC-based forward selection approach

  if(k > ncol(X)){
    stop("k cannot be greater than the number of predictors in the data set.")
  }
  remaining_predictors <- colnames(X) #Predictors that have not yet been selected

  selected_predictors <- character(0) #Initialize empty vector

  for (i in 1:k) {
    #Best performance = lowest AIC value
    best_performance <- Inf
    best_predictor <- NULL

    for (predictor in remaining_predictors) {
      predictors_to_include <- c(selected_predictors, predictor)
      model_data <- cbind(X[, predictors_to_include], y)
      model_data <- as.data.frame(model_data)  #Convert to data frame
      colnames(model_data)[ncol(model_data)] <- "y"  #Rename the last column to "y"

      if (type == "gaussian") {
        #For cont. outcome case. Do linear regression to find the top k predictors
        model <- lm(y ~ ., data = model_data)
        performance <- AIC(model)

      } else if (type == "binomial") {
        #For binary outcome case. Do logistic regression to find the top k predictors
        model <- glm(as.factor(y) ~ ., data = model_data, family = binomial)
        performance <- AIC(model)
      }
      else {
        stop("Invalid type. Please specify either 'gaussain' or 'binary'.")
      }

      if (performance < best_performance) {
        best_performance <- performance
        best_predictor <- predictor
      }
    }

    selected_predictors <- c(selected_predictors, best_predictor)
    remaining_predictors <- setdiff(remaining_predictors, best_predictor)
  }

  return(selected_predictors)
}

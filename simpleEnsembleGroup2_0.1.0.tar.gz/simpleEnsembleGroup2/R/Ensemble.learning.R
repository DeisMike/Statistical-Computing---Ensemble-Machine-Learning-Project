#' Ensemble Learning
#'
#' This function fits one combined/ensemble regression model to a dataset by
#' combining the predictions from given models. Each model and their
#' corresponding predictions (and prediction probabilities) must be created
#' using the same dataset. This is optional for the user if they want to
#' find a model with a better fit on a dataset.
#'
#' @param model1_preds,model2_preds,model3_preds,model4_preds,model5_preds,model6_preds
#' A vector of predictions for a response variable obtained from a regression
#' model.
#' @param predict_probs A data frame of the prediction probabilities for
#' each model that indicates the probability a predicted response is a certain
#' class. This should only be given when the response variables for each model
#' are all binary response variables. (NOTE: If given, this argument
#' must be named.)
#' @return A data frame object containing the predictions from each model
#' entered and the ensemble learning combined predictions.
#' @export
#' @examples
#' Sample Data
#' # Binary Response Variable Case
#' # Load data set saved within this package
#' binary_resp_data
#' testData_og = binary_resp_data
#' sampleID = sample.int(n = nrow(testData_og), size = floor(0.75*nrow(testData_og)), replace = F)
#' trainData = testData_og[sampleID, ]
#' testData = testData_og[-sampleID, ]
#' yTrain = trainData$y_binary
#' # Remove the response variable from predictor matrix
#' xTrain = data.matrix(trainData[,-21])
#' yTest = testData$y_binary
#' # Remove the response variable from predictor matrix
#' xTest = data.matrix(testData[,-21])
#' log_model = logistic(xTrain,yTrain)
#' lasso_model = Lasso(xTrain,yTrain, family = "binomial")
#' rf_model = Random.forest(xTrain,as.factor(yTrain), type = "classification")
#'
#' log_probs = predict(log_model, as.data.frame(xTest), type = "response")
#' log_probs = unname(log_probs)
#' log_preds = ifelse(log_probs > 0.5, 1, 0)
#' lasso_probs = predict(lasso_model, xTest, type = "response")
#' numcols = dim(lasso_probs)[2]
#' # From the vector of lambdas, use the lambda value that is the 50th percentile
#' lasso_probs = lasso_probs[,floor(0.5*numcols)]
#' lasso_probs = unname(lasso_probs)
#' lasso_preds = ifelse(lasso_probs > 0.5, 1, 0)
#' rf_probs = predict(rf_model, xTest, type = "prob")[,2]
#' rf_probs = unname(rf_probs)
#' rf_preds = ifelse(rf_probs > 0.5, 1, 0)
#' pred_probs_df = data.frame(Logistic = log_probs, Lasso = lasso_probs, RForest = rf_probs)
#'
#' testEnsemble = Ensemble.learning(log_preds,lasso_preds,rf_preds, predict_probs = pred_probs_df)
#' # Majority Voting
#' testEnsemble
#'
#' # Soft Voting
#' testEnsemble2 = Ensemble.learning(log_preds,rf_preds, predict_probs = pred_probs_df[,-2])
#' testEnsemble2
#'
#' # Continuous Response Variable Case
#' # Load data set saved within this package
#' continuous_y_continuous_binomial_x
#' cts_dataset = continuous_y_continuous_binomial_x
#' # Factor any categorical predictors in the data set. In this case, the x3,x4,x7, and x8 predictors
#' cts_dataset$x3 = factor(cts_dataset$x3)
#' cts_dataset$x4 = factor(cts_dataset$x4)
#' cts_dataset$x7 = factor(cts_dataset$x7)
#' cts_dataset$x8 = factor(cts_dataset$x8)
#' sampleID = sample.int(n = nrow(cts_dataset), size = floor(0.75*nrow(cts_dataset)), replace = F)
#' trainData = cts_dataset[sampleID, ]
#' testData = cts_dataset[-sampleID, ]
#' yTrain = trainData$y
#' # Remove the response variable from predictor matrix
#' xTrain = as.data.frame(data.matrix(trainData[,-11]))
#' xTrain = model.matrix(~., data = xTrain)
#' yTest = testData$y
#' # Remove the response variable from predictor matrix
#' xTest = as.data.frame(data.matrix(testData[,-11]))
#' xTest = model.matrix(~., data = xTest)
#' lin_model2 = linear(as.data.frame(xTrain),yTrain, intercept = T)
#' lasso_model2 = Lasso(xTrain,yTrain, family = "gaussian")
#' rf_model2 = Random.forest(xTrain,yTrain, type = "regression")
#' lin_preds2 = predict(lin_model2, as.data.frame(xTest))
#' lin_preds2 = unname(lin_preds2)
#' lasso_preds2 = predict(lasso_model2, newx = xTest)
#' numcols = dim(lasso_preds2)[2]
#' # From the vector of lambdas, use the lambda value that is the 50th percentile
#' lasso_preds2 = lasso_preds2[,floor(0.5*numcols)]
#' lasso_preds2 = unname(lasso_preds2)
#' rf_preds2 = predict(rf_model2, xTest)
#' rf_preds2 = unname(rf_preds2)
#' pred_df2 = data.frame(Linear = lin_preds2, Lasso = lasso_preds2, RForest = rf_preds2)
#' testEnsemble3 = Ensemble.learning(lin_preds2,lasso_preds2,rf_preds2)
#' testEnsemble3
#'
Ensemble.learning = function(model1_preds=NULL, model2_preds=NULL, model3_preds=NULL,model4_preds=NULL,model5_preds=NULL,model6_preds=NULL, predict_probs=NULL){
  if(is.null(model1_preds)==TRUE | is.null(model2_preds)==TRUE) {
    stop("Must specify at least 2 model predictions (using predict() on new data or test data, if available).")
  }
  #if(is.numeric())
  num_models = 0
  predict_list = NULL
  if(is.null(model2_preds) == FALSE & is.null(model3_preds)==TRUE) {
    num_models = 2
    predict_list = list(model1_preds, model2_preds)
  }
  if(is.null(model3_preds) == FALSE & is.null(model4_preds)==TRUE) {
    num_models = 3
    predict_list = list(model1_preds, model2_preds, model3_preds)
  }
  if(is.null(model4_preds) == FALSE & is.null(model5_preds)==TRUE) {
    num_models = 4
    predict_list = list(model1_preds, model2_preds,model3_preds,model4_preds)
  }
  if(is.null(model5_preds) == FALSE & is.null(model6_preds)==TRUE) {
    num_models = 5
    predict_list = list(model1_preds, model2_preds,model3_preds,model4_preds,model5_preds)
  }
  if(is.null(model5_preds) == FALSE & is.null(model6_preds)==FALSE) {
    num_models = 6
    predict_list = list(model1_preds, model2_preds,model3_preds,model4_preds,model5_preds,model6_preds)
  }
  userChoice = readline(prompt = "What is the response variable type being predicted in each of the models? (binary or continuous): ")

  predictions_df = as.data.frame(predict_list)
  colnames(predictions_df) = c(1:length(predict_list))
  if(userChoice == "binary") { #Classification - soft voting & hard voting
    if(num_models <= 1) {
      stop("1 or fewer models were supplied; check spelling of models is correct and matches the names in the tutorial page")
    }
    if(is.null(predict_probs)==T) {
      stop("A data frame of the prediction probabilities must be provided when the response variables are binary")
    }
    if(num_models == 2 | num_models == 4 | num_models == 6) { # Soft voting since there could be ties between models
      combinedPreds = (apply(predict_probs, 1, sum)) / num_models
      combinedPred2 = unname(combinedPreds)
      predictions_df$Ensemble = ifelse(combinedPred2 > 0.5, 1, 0)
      return(predictions_df)
    }
    else if(num_models == 3 | num_models == 5) { # Hard/majority voting (no ties possible)
      model_predictions2 = as.matrix(predictions_df)
      predictions_df$Ensemble = apply(model_predictions2,1,function(x) {
        freq = table(x)
        mode = as.numeric(names(freq)[freq == max(freq)])
      })
      return(predictions_df)
    }
  }
  else if(userChoice == "continuous") { #Regression - Simple Averaging of the predictions
    if(num_models <= 1) {
      stop("1 or fewer models were supplied; check spelling of models is correct and matches the names in the tutorial page")
    }
    if(is.null(predict_probs)==F) {
      stop("A data frame of the prediction probabilities cannot be used when the response variable type is continuous")
    }
    predictions_df$Ensemble = rowMeans(predictions_df, na.rm = T)
    return(predictions_df)
  }
  else {
    stop("response variable type must be either continuous or binary")
  }
}

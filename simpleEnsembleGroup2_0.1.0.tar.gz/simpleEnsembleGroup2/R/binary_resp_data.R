#' Sample data with binary response variable and 20 cont. predictors
#'
#' This data frame contains sample data for testing functions.
#' @format A data frame with 100 observations and 20 predictors and 1 binary outcome variable:
#' \describe{
#'   \item{x1}{Numeric: Example predictor 1}
#'   \item{x2}{Numeric: Example predictor 2}
#'   ...
#'   \item{x20}{Numeric: Example predictor 20}
#'   \item{y_binary}{Factor: Binary response variable}
#' }
#'
#' @examples
#' data(binary_resp_data)
binary_resp_data <- data.frame(
  x1 = rnorm(100),
  x2 = rnorm(100),
  x3 = rnorm(100),
  x4 = rnorm(100),
  x5 = rnorm(100),
  x6 = rnorm(100),
  x7 = rnorm(100),
  x8 = rnorm(100),
  x9 = rnorm(100),
  x10 = rnorm(100),
  x11 = rnorm(100),
  x12 = rnorm(100),
  x13 = rnorm(100),
  x14 = rnorm(100),
  x15 = rnorm(100),
  x16 = rnorm(100),
  x17 = rnorm(100),
  x18 = rnorm(100),
  x19 = rnorm(100),
  x20 = rnorm(100),
  y_binary = factor(sample(0:1, 100, replace = TRUE))
)

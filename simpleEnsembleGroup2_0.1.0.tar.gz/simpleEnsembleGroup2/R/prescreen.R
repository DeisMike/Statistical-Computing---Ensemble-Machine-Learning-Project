#' Pre-screen for the K Most Informative Predictors Main Function
#'
#' This function chooses which method to use to select the k most informative predictors .
#' If we are dealing with a large data set, the function will call either prescreen.bc,
#' prescreen.bb, prescreen.cb, or prescreen.cc depending on the type of the predictors
#' and type of response (binary or continuous). If the data set is small, the function calls
#' the prescreen.fs as the variable selection method.
#'
#' @param X Matrix of candidate predictors/independent variables.
#' @param y Response variable. For binary classification, it should be a
#' vector of factor variable with two levels. For linear regression, it should be a
#' numeric vector.
#' @param k The number of predictors to be included in the model. k is a positive integer.
#' @param type Type of model. Options are \code{"gaussian"} (Default) for continuous response
#' and \code{"binary"} for binary response.
#'
#' @return A vector of k selected predictors
#'
#' @export
#' @examples
#'
#'#Ex. 1:
#' #Check the structure of data to see the types of each variable
#' str(gene.data)
#' #Call the prescreen function to work on data set where p >> n
#' prescreen(gene.data[-1], gene.data$Group, 20)
#'
#'#Ex. 2:
#'
#'#Check the structure of data to see the types of each variable
#'str(binary_resp_data)
#'prescreen(binary_resp_data[,-21], binary_resp_data$y_binary, 5, type = "binomial")
#'
#' @seealso \code{\link{prescreen.fs}}, \code{\link[prescreen]{prescreen.scale}}
#'

prescreen <- function(X, y, k, type = "gaussian") {
  if (k <= 0) {
    stop("k must be a positive integer.")
  }
  if (k > ncol(X)){
    stop("k cannot be larger than the number of predictors.")
  }

  #Check data set size
  if (nrow(X) < 1000 & ncol(X) < 40 & k < 40) {
    # Use prescreen.fs for smaller datasets
    return(prescreen.fs(X, y, k, type = type))
  }

  #Check if response variable is binary
  if (is.factor(y)) {
    if (all(sapply(X, is.numeric))) {  #Check if predictors are numeric
      return(prescreen.cb(X, y, k))  #Use prescreen.cb (cont. predictors, binary response)
    } else {
      stop("Invalid data set type. This function does not work for binary predictors and binary response")
      #Use a function named prescreen.bb for (binary predictors, binary response)
    }
  } else {  #Response variable is continuous case
    if (all(sapply(X, is.numeric))) {  #Check if predictors are numeric
      stop("Invalid data set type. This function does not work for binary predictors and a continuous response")
      #Use a function named prescreen.bc (binary predictors, cont. response)
    } else {
      return(prescreen.cc(X, y, k))  #Use prescreen.cc for (cont. predictors, cont. reponse)
    }
  }
}


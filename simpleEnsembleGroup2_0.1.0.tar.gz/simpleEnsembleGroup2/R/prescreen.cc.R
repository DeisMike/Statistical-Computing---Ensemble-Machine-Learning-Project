#' Pre-screen for the K Most Informative Predictors (continuous X & y, large data set case)
#'
#' This function is used when dealing with a large data set with both X and y being
#' continuous. This function looks at the magnitude of the correlation values between predictors and the
#' outcome variable and returns the top k predictors with the largest correlation magnitude.
#'
#' @param X Matrix of candidate predictors/independent variables.
#' @param y Continuous response variable.
#' @param k The number of predictors to be included in the model. k is a positive integer.
#'
#' @return A vector of k selected predictors
#'
#' @export
#' @examples
#'
#'#Example:
#'str(cc.data)
#'prescreen.cc(cc.data[,-51], cc.data$outcome, 10)
#'
#' @seealso \code{\link{prescreen}}
#'

prescreen.cc <- function(X, y, k){
  #Method for cont. predictors and cont. response
  #Look at correlation between the predictors and the response variable
  correlations <- cor(X, y)

  #Create new data frame to keep track of names of the predictors
  corr_with_names <- data.frame(predictor = colnames(X),
                                correlation = correlations)

  #Order by the correlation magnitude and select top k predictors
  top_predictors <- corr_with_names[order(abs(corr_with_names$correlation),
                                          decreasing = TRUE), "predictor"][1:k]

  return(top_predictors)
}


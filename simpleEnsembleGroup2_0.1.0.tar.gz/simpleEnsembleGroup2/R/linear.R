#' Fit a linear regression model
#'
#' This function performs linear regression on the provided data set using the
#' least squares method. If there are any missing values in either the set of
#' predictors or the response variable, the observation will be removed before
#' fitting the model.

#' @param X Matrix of candidate predictors/independent variables. If there are categorical
#' predictors, the user must enter X such that those variables are already of the factor type
#' in R and use model.matrix to create necessary dummy variables for the categorical predictors.
#' @param y Response variable that should be a numeric vector of continuous values.
#' @param intercept A logical value indicating whether to include an intercept
#' term in the regression model. If set to FALSE, the intercept term will be
#' excluded. Default is TRUE
#' @param k k Option to pre-screen for the top k most informative predictors. Default is no pre-screening.
#'
#' @return Linear regression model object
#' @export
#' @examples
#' # Sample Data
#' X <- data.frame(data=cbind(ChickWeight$Time, ChickWeight$Diet))
#' #Here, Diet is a categorical variable and so the user must make that column a factor variable.
#' X[,2] <- as.factor(X[,2])
#' #The user can check the variable types for each column using the following:
#' str(X)
#' y <- ChickWeight$weight
#'
#' #Example usage
#' example_linear_model <- linear(X, y, intercept="FALSE")
#'
#' #ANOTHER EXAMPLE:
#' #Example usage
#' set.seed(123)
#'cont_resp_data <- data.frame(
#'  x1 = rnorm(100),
#'  x2 = rnorm(100),
#'  x3 = rnorm(100),
#'  x4 = rnorm(100),
#'  x5 = rnorm(100),
#'  x6 = rnorm(100),
#'  x7 = rnorm(100),
#'  x8 = rnorm(100),
#'  x9 = rnorm(100),
#' x10 = rnorm(100),
#'  y <- rnorm(n, mean = 100, sd = 20))
#' #Fit linear regression model with all predictors
#' ex_reg <- linear(X = cont_resp_data[-11], y = cont_resp_data$y, intercept = FALSE)
#' #Check AIC value
#' AIC(ex_reg)
#' #Fit linear regression model with prescreening
#' pre_ex_reg <- linear(X = cont_resp_data[-11], y = cont_resp_data$y, intercept = FALSE, k = 4)
#' #Check AIC after pre-screen to see if it is lower (better model)
#' AIC(pre_ex_reg)
#' @seealso \code{\link{lm}}, \code{\link[prescreen]{prescreen}}
#'
linear <- function(X, y, intercept, k = NULL){

  X <- na.omit(X)
  y <- na.omit(y)

  #Convert into data frame if not already
  X <- as.data.frame(X)

  if(!is.null(k)) {
    #If there is a specified value for k, do pre-screening
    predictors <- prescreen(X, y, k, type = "gaussian")
    X <- X[, predictors]
  }

  #Create a data frame with X and y
  data_matrix <- as.data.frame(X)
  data_matrix$response <- y

  model <- lm(response~., data = data_matrix)

  if(intercept == FALSE){
    model <- lm(response~.-1, data = data_matrix)
  }
  return(model)
}

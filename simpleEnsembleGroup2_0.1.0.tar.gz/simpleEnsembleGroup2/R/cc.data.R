#' Sample data (continuous X and continuous y with many predictors)
#'
#' This function generates simulated data with continuous predictors and a continuous outcome variable.
#' The data is useful for testing functions and algorithms in the group2package.
#'
#' @return A data frame containing simulated data with continuous predictors (X1 to X50) and a continuous outcome variable.
#' @export
#'
#' @examples
#' simulated_data <- generate_simulated_data()
#' head(simulated_data)
#'
#'

n <- 1000
p <- 50
#Generate predictors
predictors <- predictors <- matrix(rnorm(n * p),
                                   nrow = n, ncol = p,
                                   dimnames = list(NULL, paste0("X", 1:p)))
#Generate continuous outcome
outcome <- rnorm(n)
cc.data <- data.frame(predictors, outcome)


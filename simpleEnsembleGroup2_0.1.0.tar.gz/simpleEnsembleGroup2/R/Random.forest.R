#' Perform Random Forest Regression
#'
#' This function performs Random Forest regression on a response variable. It assumes
#' the response variable is either binary or continuous. Utilizes the randomForest
#' package to perform the regression. Any missing values
#' in either the set of predictors or the response variable will be removed
#' from the regression as part of data cleaning.
#'
#' @param x A matrix of the predictor/covariate variables
#' @param y Response variable y
#' @param type Type of model. Options are \code{"regression"}
#' and \code{"classification"}.
#' @param k Option to pre-screen for the top k most informative predictors. Default is no pre-screening.
#' @return A Random.forest model object.
#' @export
#' @import randomForest
#' @examples
#' #Sample Data
#' set.seed(123)
#' # For binary outcome
#' binary_data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y_binary = factor(sample(0:1, 100, replace = TRUE)))
#' bin_x_data = as.matrix(binary_data[1:2])
#'
#' # For continuous outcome
#' continuous_data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y_continuous = rnorm(100))
#' cts_x_data = as.matrix(continuous_data[1:2])
#'
#' #Example usage for binary outcome
#' bin_model = Random.forest(
#' bin_x_data,
#' binary_data$y_binary,
#' type = "classification")
#'
#' #Example usage for continuous outcome
#' cts_model = Random.forest(cts_x_data, continuous_data$y_continuous)
#'
#' # Summary of the fitted models
#' summary(bin_model)
#' summary(cts_model)

Random.forest = function(X= NULL,y= NULL, type = c("regression", "classification"), k = NULL) {
  # Use match.arg to match the argument to the allowed options
  type = match.arg(type)
  # Remove missing values from the predictors and response variable
  X = na.omit(X)
  y = na.omit(y)
  if(is.null(X)==T) {
    stop("first argument, x, must be provided, formatted as a matrix")
  }
  if(is.null(y)==T) {
    stop("second argument, y, must be provided, formatted as a vector")
  }
  if(is.matrix(X)==F) {
    stop("x must be a matrix")
  }
  if(length(unique(y))==1) {
    stop("y must have more than one unique value")
  }
  if(is.character(y)==T & length(unique(y)) > 2) {
    stop("y must be binary (2 unique values) if it is a character vector")
  }
  if(!is.null(k)) {
    if(type == "classification"){
      predictors <- prescreen(X, y, k, type = "binary")
      X <- X[, predictors]
    }
    if(type == "regression"){
      predictors <- prescreen(X, y, k, type = "gaussian")
      X <- X[, predictors]
    }
  }
  rfData = as.data.frame(X)
  rfData$response = y
  if(type == "classification") {
    # Binary case - classification
    if(length(unique(y)) != 2){
      stop("y must have 2 unique values when type is classification")
    }
    rfModel = randomForest::randomForest(response ~ ., data = rfData, type = "classification")
  }
  else if(type == "regression") {
    # Continuous case - regression
    if(length(unique(y)) == 2){
      stop("y must have more than 2 unique values when type is regression")
    }
    if(is.vector(y)==F) {
      stop("y must be a vector of the response variable")
    }
    rfModel = randomForest::randomForest(response ~ ., data = rfData, type = "regression")
  }
  return(rfModel)
}
